

<?php $__env->startSection('container'); ?>
    <?php if(session('status')): ?>
        <script>
            alert('Pesanan berhasil dibuat silahkan melakukan pembayaran dikasir terdekat');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>
    <?php if(session('statusedit')): ?>
        <script>
            alert('Pesanan berhasil diedit');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>

    <?php if(session('kosong')): ?>
        <script>
            alert('Keranjang anda masih kosongS');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>
    <!-- page start-->

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">

                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <div class="col-xl-12 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <a class="btn btn-primary btn-lg" href="/menu/cart">Back</a>
                                                <div class="table-responsive">
                                                    <table class="table table-striped table-advance table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Kode</th>
                                                                <th>Tanggal</th>
                                                                <th>Total Harga
                                                                <th>Status</th>
                                                                <th>Aksi</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e($trx->kode_trx); ?></td>
                                                                    <td><?php echo e($trx->created_at); ?></td>
                                                                    <td>Rp
                                                                        <?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?>

                                                                    </td>
                                                                    <td><?php echo e($trx->status); ?></td>

                                                                    <td>
                                                                        <div class="btn-group">
                                                                            <form action="/history/<?php echo e($trx->No_trx); ?>"
                                                                                method="post">
                                                                                <?php echo csrf_field(); ?>
                                                                                <input type="hidden" name="status"
                                                                                    value="diterima">
                                                                                <button class="btn btn-success"
                                                                                    onclick="return confirm('Pesanan anda telah anda terima?');"><i
                                                                                        class="fas fa-check-double"></i></button>
                                                                            </form>


                                                                            <button type="button" class="btn btn-info"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#lihatDetail-<?php echo e($trx->kode_trx); ?>"
                                                                                data-bs-whatever="@getbootstrap"><i
                                                                                    class="fas fa-eye"></i></button>
                                                                        </div>

                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                        </tbody>
                                                    </table>
                                                </div>
                        </section>
                    </div>
                </div>





                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal" id="lihatDetail-<?php echo e($trx->kode_trx); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">

                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title centered" id="exampleModalLabel">
                                        &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        NOTA </h2>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <h5><?php echo e($trx->kode_trx); ?></h5>
                                    <table class="table table-striped table-advance table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Menu</th>
                                                <th>Qty</th>
                                                <th>Harga</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $notas->where('kode_trx', $trx->kode_trx); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($nota->menu->nama_menu); ?></td>
                                                    <td><?php echo e($nota->jml_beli); ?> </td>
                                                    <td>Rp <?php echo e($nota->total_harga); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                    <h6>Total Harga :
                                        <?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?></td>
                                        </br></br>
                                        Total bayar&nbsp; :
                                        <?php echo e($nota->total_bayar); ?></td>
                                        </br></br>
                                        Kembali &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;:
                                        <?php echo e($nota->kembalian); ?></td>
                                    </h6>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>
    <!-- page end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cartMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/customers/history.blade.php ENDPATH**/ ?>