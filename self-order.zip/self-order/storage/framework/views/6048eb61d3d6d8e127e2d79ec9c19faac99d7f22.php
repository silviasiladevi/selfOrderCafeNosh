

<?php $__env->startSection('container'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold ">Daftar Transaksi</h6>
            </div>

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama user</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasir')): ?>
                                    <th>Update status</th>
                                <?php endif; ?>
                                <th>Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($trx->user->fullname); ?></td>
                                    <td><?php echo e($trx->kode_trx); ?></td>
                                    <td><?php echo e($trx->created_at); ?></td>
                                    <td>Rp <?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?></td>
                                    <td><?php echo e($trx->status); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasir')): ?>


                                        <td>
                                            <div class="btn-group">
                                                <form action="keloladaftar/<?php echo e($trx->No_trx); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="diproses">
                                                    <button class="btn btn-info"
                                                        onclick="return confirm('Transaksi ini akan diproses ?');"><i
                                                            class="fas fa-hourglass-start"></i></button>
                                                </form>
                                                <form action="keloladaftar/<?php echo e($trx->No_trx); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="selesai">
                                                    <button class="btn btn-danger"
                                                        onclick="return confirm('Transaksi ini telah selesai?');"><i
                                                            class="fas fa-check-double"></i></button>
                                                </form>

                                            </div>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="btn-group">

                                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                                data-bs-target="#lihatDetail-<?php echo e($trx->kode_trx); ?>"
                                                data-bs-whatever="@getbootstrap"><i class="fas fa-eye"></i></button>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasir')): ?>

                                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#updatePembayaran-<?php echo e($trx->kode_trx); ?>"
                                                    data-bs-whatever="@getbootstrap"><i
                                                        class="fas fa-cash-register"></i></button>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <form action="keloladaftar/<?php echo e($trx->kode_trx); ?>" method="post">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?> <button type="submit" class="btn btn-danger"
                                                        onclick="return confirm('apakah anda yakin ingin menghapus transaksi ini?');">
                                                        <i class="fas fa-trash"></i></button>
                                                </form>

                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Total Pemasukan :</td>
                                <td> Rp <?php echo e($notas->where('status', '!=', 'menunggu pembayaran')->sum('total_harga')); ?>

                                </td>
                                <td></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasir')): ?>
                                    <td></td>
                                <?php endif; ?>

                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

    </div>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="updatePembayaran-<?php echo e($trx->kode_trx); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">

            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title centered" id="exampleModalLabel">
                            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            UPDATE </h2>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h5><?php echo e($trx->kode_trx); ?></h5>
                        <table class="table table-striped table-advance table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Menu</th>
                                    <th>Qty</th>
                                    <th>Harga</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $notas->where('kode_trx', $trx->kode_trx); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($nota->menu->nama_menu); ?></td>
                                        <td><?php echo e($nota->jml_beli); ?> </td>
                                        <td>Rp <?php echo e($nota->total_harga); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        <h6>Total Harga : Rp
                            <?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?></td>
                        </h6>
                        </br>

                        <form action="/homeAdmin/keloladaftar/bayar/<?php echo e($trx->No_trx); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="kasir">

                                <input type="hidden" name="total_harga" id="total" class="total"
                                    data-price="<?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?>"
                                    value="<?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?>">
                                <h6>Total bayar&nbsp;
                                    <input type="number" id="bayar" name="total_bayar" step="100" min="0"
                                        value="<?php echo e($nota->total_bayar); ?>" class="form-control" required>

                                </h6>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="lihatDetail-<?php echo e($trx->kode_trx); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">

            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title centered" id="exampleModalLabel">
                            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                            DETAIl TRANSAKSI </h2>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h5><?php echo e($trx->kode_trx); ?></h5>
                        <table class="table table-striped table-advance table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Menu</th>
                                    <th>Qty</th>
                                    <th>Harga</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $notas->where('kode_trx', $trx->kode_trx); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($nota->menu->nama_menu); ?></td>
                                        <td><?php echo e($nota->jml_beli); ?> </td>
                                        <td>Rp <?php echo e($nota->total_harga); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        <h6>Total Harga :
                            <?php echo e($notas->where('kode_trx', $trx->kode_trx)->sum('total_harga')); ?></td>
                            </br></br>
                            Total bayar&nbsp; :
                            <?php echo e($nota->total_bayar); ?></td>
                            </br></br>
                            Kembali &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;:
                            <?php echo e($nota->kembalian); ?></td>
                        </h6>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End of Main Content -->

    <!-- Footer -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/admin/kelolaDaftarTrx.blade.php ENDPATH**/ ?>