
<?php $__env->startSection('container'); ?>

    <div class="brand-wrapper">
        <img src="/img/Nosh/logo.png" alt="logo" style="height: 80px">


    </div>
    <p class="login-card-description">Sign into your account</p>

    <form action="/login" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <?php if(session()->has('success')): ?>

                <div class="alert alert-success alert-dismissible show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>

                <div class="alert alert-danger alert-dismissible show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>
            <label for="username" class="sr-only">Username <i class="fas fa-user"></i></label>
            <input type="text" name="username" id="username" class="form-control" placeholder="Masukkan Username" required>

        </div>
        <div class="form-group mb-4">
            <label for="password" class="sr-only">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password"
                required>
        </div>
        <button class="btn btn-block login-btn mb-4" type="submit"> Login</button>
    </form>
    <p class="login-card-footer-text">Don't have an account? <a href="/regis">Register here!</a>
    </p>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.loginMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/login.blade.php ENDPATH**/ ?>