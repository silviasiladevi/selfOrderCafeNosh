

<?php $__env->startSection('container'); ?>
    <?php if(session('status')): ?>
        <script>
            alert('Pesanan berhasil dibuat silahkan melakukan pembayaran dikasir terdekat');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>
    <?php if(session('statusedit')): ?>
        <script>
            alert('Pesanan berhasil diedit');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>

    <?php if(session('kosong')): ?>
        <script>
            alert('Keranjang anda masih kosong ..');
            // document.location.href = '/dashboard';
        </script>
    <?php endif; ?>
    <!-- page start-->

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">

                <a class="btn btn-primary btn-lg" href="/history">History</a>
                <div class="table-responsive">


                    <table class="table table-striped table-advance table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Gambar Produk</th>
                                <th>Nama Menu</th>
                                <th>Jumlah_beli</th>
                                <th>total_Harga</th>
                                <th> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?> </td>
                                    <td><img width="150px" src="<?php echo e(Storage::url($cart->menu->pic)); ?>"></td>
                                    <td><?php echo e($cart->menu->nama_menu); ?></td>
                                    <td>
                                        <form role="form" action="/cart/<?php echo e($cart->id); ?>/update" method="post"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($cart->id); ?>">
                                            
                                            <input type="hidden" name="price" value="<?php echo e($cart->menu->price); ?>">



                                            <input type="number" name="jml_beli" id="jml_beli"
                                                placeholder="<?php echo e($cart->jml_beli); ?>" max="10000" min="1"
                                                value="<?php echo e($cart->jml_beli); ?>" class="form-control" required>
                                            
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </form>

                                    </td>
                                    <td>Rp <?php echo e($cart->total_harga); ?> </td>
                                    <td>
                                        <form action="<?php echo e($cart->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <div class="btn-group">
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Data ini akan dihapus');"><i
                                                        class="fas fa-trash"></i></button>

                                            </div>

                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Total Bayar : <?php echo e($carts->sum('total_harga')); ?></td>
                                <td></td>
                                <td>
                                    <form action="/menu/cart/checkout" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                        <button class="btn btn-primary btn-lg" type="submit"
                                            onclick="return confirm('Pesanan Akan dibuat');">Checkout</button>
                                </td>
                                </form>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>

    <!-- page end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cartMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/customers/cart.blade.php ENDPATH**/ ?>