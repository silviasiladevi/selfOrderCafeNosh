<div class="placeholder">
    <div class="parallax-window" data-parallax="scroll" data-image-src="img/Nosh/NoshHome.jpeg">
        <div class="tm-header">

            <div class="row tm-header-inner">
                <div class="col-md-2 col-12 ">
                    <img src="img/Nosh/NoshLogoPutih.png" alt="Logo" class="tm-site-logo" style="height: 200px" />
                </div>

                <nav class="col-md-2 col-12">
                    <ul class="tm-nav-ul">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <li class="tm-nav-li">
                                <a class="tm-nav-link <?php echo e($title === 'admin' ? 'active' : ''); ?>" href="/homeAdmin">Admin</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kasir')): ?>
                            <li class="tm-nav-li">
                                <a class="tm-nav-link <?php echo e($title === 'kasir' ? 'active' : ''); ?>"
                                    href="/homeAdmin">Kasir</a>
                            </li>
                        <?php endif; ?>
                        <li class="tm-nav-li">
                            <a class="tm-nav-link <?php echo e($title === 'Menu' ? 'active' : ''); ?>" href="/">Menu</a>
                        </li>
                        <li class="tm-nav-li">
                            <a class="tm-nav-link <?php echo e($title === 'About' ? 'active' : ''); ?>" href="/about">About</a>
                        </li>

                        <li class="tm-nav-li">
                            <form action="/logout" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" style="background-color: transparent; border:none"
                                    class="tm-nav-link <?php echo e($title === 'Logout' ? 'active' : ''); ?>">
                                    <h2 style="font-style: normal">Logout</h2>
                                </button>
                            </form>
                            
                        </li>
                        

                    </ul>
                </nav>

            </div>

        </div>

    </div>

</div>
<?php /**PATH E:\applications\self-order\resources\views/partials/navbar.blade.php ENDPATH**/ ?>