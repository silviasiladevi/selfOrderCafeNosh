

<?php $__env->startSection('container'); ?>

    <!-- page start-->

    <div class="row">

        <div class="col-lg-12">
            <section class="panel">
                <div class="col-xl-12 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <section id="main-content">

                                <form role="form" action="/menu" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="namamenu">Nama Menu</label>
                                        <input type="text" name="nama_menu" class="form-control" id="namamenu"
                                            placeholder="Masukkan nama menu" value="<?php echo e(old('nama_menu')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="type">Jenis</label>
                                        <select id="type" class="form-control" name="type"
                                            placeholder="Masukkan jenis menu" value="<?php echo e(old('type')); ?>">
                                            <option>makanan</option>
                                            <option>minuman</option>
                                            <option>dessert</option>

                                        </select>
                                        <!-- <input type="text" name="jenis" class="form-control" id="exampleInputEmail1" placeholder="Jenis"> -->
                                    </div>
                                    <div class="form-group">
                                        <label for="desc">Deskripsi</label>
                                        <input type="text" name="desc" class="form-control" id="desc"
                                            placeholder="Masukkan deskripsi menu" value="<?php echo e(old('desc')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="price">Harga</label>
                                        <input type="number" name="price" class="form-control" id="price"
                                            placeholder="Masukkan harga menu" value="<?php echo e(old('price')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="pic">Unggah Foto</label>
                                        <input type="file" name="pic" id="pic" value="<?php echo e(old('pic')); ?>"
                                            class="form-contorl  <?php $__errorArgs = ['pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <button type="submit" name="submit" class="btn btn-primary">ADD</button>
                                </form>

                        </div>

                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- page end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/admin/formTambahMenu.blade.php ENDPATH**/ ?>