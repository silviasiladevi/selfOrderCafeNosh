

<?php $__env->startSection('container'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->


        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                Daftar User


            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Lengkap</th>
                                <th>Username</th>
                                <th>No.Telp</th>
                                <th>Email</th>
                                <th>Jabatan</th>
                                <th>Ubah Jabatan</th>
                                <th>Hapus</th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->fullname); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->nomor_hp); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->jabatan); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <form action="kelolauser/<?php echo e($user->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="jabatan" value="admin">
                                                <button class="btn btn-primary"
                                                    onclick="return confirm('Jadikan user ini admin?');"><i
                                                        class="fas fa-user-shield"></i></button>
                                            </form>
                                            <form action="kelolauser/<?php echo e($user->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="jabatan" value="kasir">
                                                <button class="btn btn-secondary"
                                                    onclick="return confirm('Jadikan user ini kasir?');"><i
                                                        class="fas fa-hand-holding-usd"></i></button>
                                            </form>
                                            <form action="kelolauser/<?php echo e($user->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="jabatan" value="customer">
                                                <button class="btn btn-info"
                                                    onclick="return confirm('Jadikan user ini customer?');">
                                                    <i class="fas fa-user-alt"></i>
                                                </button>
                                            </form>

                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <form action="kelolauser/<?php echo e($user->id); ?>" method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Anda yakin ingin menghapus user ini?');"><i
                                                        class="fas fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\self-order\resources\views/admin/kelolaUser.blade.php ENDPATH**/ ?>