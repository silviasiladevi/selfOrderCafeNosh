<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Transaction;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function keloladaftar()
    {
        $trans = Transaction::all();
        $notas = Transaction::all();
        $menus = Menu::all();
        // $transactions = Transaction::orderBy('kode_trx', 'desc')->groupBy('kode_trx')->get();
        DB::statement("SET SQL_MODE=''");
        $transactions = Transaction::groupBy('kode_trx')->orderBy('created_at', 'DESC')->get();
        // dd($transactions);

        return view('admin/kelolaDaftarTrx', [
            "transactions" => $transactions,
            "notas" => $notas,
            "menus" => $menus,
            "title" => "trx",
            "page" => "Kelola Daftar Transaksi"
        ]);
    }

    public function history()
    {
        $trans = Transaction::all();
        $notas = Transaction::all();
        $userId = Auth::id();
        $menus = Menu::all();
        // $transactions = Transaction::orderBy('kode_trx', 'desc')->groupBy('kode_trx')->get();
        DB::statement("SET SQL_MODE=''");
        $transactions = Transaction::where('user_id', $userId)->groupBy('kode_trx')->orderBy('kode_trx', 'desc')->get();
        // dd($transactions);

        return view('customers/history', [
            "transactions" => $transactions,
            "notas" => $notas,
            "menus" => $menus,
            "title" => "history",
            "page" => "HISTORY"
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userId = Auth::id();
        $carts = Cart::where('user_id', $userId)->get();
        $maxkode = Transaction::select('kode_trx')->orderBy('kode_trx', 'desc')->first();
        $maxkodenew = $maxkode->kode_trx;
        $urutan = (int) substr($maxkodenew, 5, 5);
        // bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
        $urutan++;
        // // membentuk kode barang baru
        // // perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
        // // misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
        // // angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
        $huruf = "TRX";
        $kode_cart = $huruf . sprintf("%05s", $urutan);

        if (Cart::where('user_id', '=', $userId)->exists()) {
            // user found

            foreach ($carts as $cart) {
                // $menu_id = $cart["id_produk"];
                // $jumlah_beli = $cart["jumlah_beli"];

                // $query         = "CALL insert_transaksi('$id_produk','$jumlah_beli','$kode_cart','$id_user')";
                // mysqli_query($db_con, $query);

                $trx = new Transaction();
                $trx->kode_trx = $kode_cart;
                $trx->menu_id = $cart->menu_id;
                $trx->user_id = $cart->user_id;
                $trx->jml_beli = $cart->jml_beli;
                $trx->total_harga = $cart->total_harga;
                $trx->total_bayar = 0;
                $trx->kembalian = 0;
                $trx->status = 'menunggu pembayaran';
                $trx->save();
            }
            $carts->each->delete();

            return redirect("/history")->with('success', 'Pesanan telah dibuat silahkan melakukan pembayaran dikasir terdekat!');
        }
        return redirect("/menu/cart")->with('warning', 'Keranjang anda masih kosong :(');
    }

    public function updateStatus(Request $request, Transaction $trx)
    {
        $trxs = Transaction::where('kode_trx', $trx->kode_trx)->get();

        foreach ($trxs as $trx) {
            $trx->status = $request->status;
            $trx->save();
        }
        return redirect("/homeAdmin/keloladaftar")->with('toast_success', 'Status berhasil diupdate');
        // $trx->status = $request->status;
        // $trx->save();
    }

    public function updateStatusCus(Request $request, Transaction $trx)
    {
        $trxs = Transaction::where('kode_trx', $trx->kode_trx)->get();

        foreach ($trxs as $trx) {
            $trx->status = $request->status;
            $trx->save();
        }
        return redirect("/history")->with('toast_success', 'Terimakasih!');
        // $trx->status = $request->status;
        // $trx->save();
    }

    public function updateBayar(Request $request, Transaction $trx)
    {
        $trxs = Transaction::where('kode_trx', $trx->kode_trx)->get();
        $harga = $trxs->sum('total_harga');
        foreach ($trxs as $trx) {
            $trx->total_bayar = $request->total_bayar;
            $harga = $trxs->sum('total_harga');
            $trx->kembalian = ($request->total_bayar) - $harga;
            $trx->status = "diproses";
            $trx->save();
        }
        return redirect("/homeAdmin/keloladaftar")->with('success', 'Pembayaran telah selesai :)');
        // $trx->status = $request->status;
        // $trx->save();
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($trx)
    {
        $data = Transaction::where('kode_trx', $trx);
        $data->delete();


        return redirect('/homeAdmin/keloladaftar')->with('success', 'Transaksi Berhasil Dihapus!');
    }
}